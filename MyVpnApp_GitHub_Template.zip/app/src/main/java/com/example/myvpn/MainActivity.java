package com.example.myvpn;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    boolean connected = false;
    TextView status;
    Button connect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        connect = findViewById(R.id.connect);

        connect.setOnClickListener(v -> {
            connected = !connected;
            if (connected) {
                status.setText("✅ Connected");
                connect.setText("Disconnect");
            } else {
                status.setText("❌ Disconnected");
                connect.setText("Connect");
            }
        });
    }
}
